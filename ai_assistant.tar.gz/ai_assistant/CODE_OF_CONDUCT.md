# Code of Conduct

Be respectful and constructive. Harassment or abuse is not tolerated. Maintain professionalism in issues and PRs.